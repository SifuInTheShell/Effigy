try:
    from . import triton
except ImportError:  # no Triton (e.g. Windows + ROCm): only Algorithm.EXPLICIT_GEMM is usable
    triton = None
from . import cuda
