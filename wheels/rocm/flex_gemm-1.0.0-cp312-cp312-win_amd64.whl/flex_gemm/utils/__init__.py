try:
    from .autotuner import autotune, save_autotune_cache, load_autotune_cache, get_autotune_cache
except ImportError:  # no Triton
    autotune = save_autotune_cache = get_autotune_cache = None
    def load_autotune_cache(*a, **k):
        pass
